package cscd212interfaces;

public interface HolidayItem {

    double getCost();

    String getDescription();
}
