package cscd212classes.lifeform;

/**
 * Human class
 */
public class Kryptonians extends LifeForm{

    /** Kryptonians constructor
     *
     * @param name String
     * @param currentLifePoints int
     */
        public Kryptonians(String name, int currentLifePoints) {
            super(name, currentLifePoints);
        }
}
