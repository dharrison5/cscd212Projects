package cscd212classes.lifeform;

/**
 * HalfOrc class
 */
public class HalfOrc extends LifeForm{

    /**
     * HalfOrc constructor
     * @param name String
     * @param currentLifePoints int
     */
    public HalfOrc(String name, int currentLifePoints) {
        super(name, currentLifePoints);
    }
}
