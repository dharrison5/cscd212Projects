package cscd212classes.lifeform;

/**
 * Martian class
 */
public class Martian extends LifeForm{

    /**
     * Martian constructor
     * @param name String
     * @param currentLifePoints int
     */
    public Martian(String name, int currentLifePoints) {
        super(name, currentLifePoints);
    }
}
