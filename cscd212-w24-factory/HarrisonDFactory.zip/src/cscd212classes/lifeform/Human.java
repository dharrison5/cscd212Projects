package cscd212classes.lifeform;

/**
 * Human class
 */
public class Human extends LifeForm{

    /**
     * Human constructor
     * @param name String
     * @param currentLifePoints int
     */
    public Human(String name, int currentLifePoints) {
        super(name, currentLifePoints);
    }
}
