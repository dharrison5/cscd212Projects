package cscd212enums;

/**
 * BoardTheme enum
 */
public enum BoardTheme {
    EARTH, FANTASY, MARS;
}
